# 🤖 YT Downloader Pro — Telegram Bot

Send a YouTube link → pick 🎵 MP3 or 🎬 MP4 → pick quality → get the file in chat, with a live progress bar.

## ✨ Features
- Professional inline-button menus with icons (Main menu, Settings, History, Stats, Help, About)
- Video card with thumbnail, channel, duration, views and upload date
- MP3 128 / 192 / 320 kbps and MP4 Best / 1080p / 720p / 480p / 360p (only resolutions the video really has)
- Estimated file size per quality, with ⚠️ when it would exceed the upload limit
- Live progress: bar, %, speed, ETA, converting / uploading phases, 🛑 Stop button
- Playlists: choose First 1 / 5 / 10 / All, files sent one by one, temp files deleted after each item
- 🖼 HD thumbnail download, 📃 "use full playlist" switch for links that contain both a video and a list
- Per-user settings (default action, audio and video quality) → "quick mode" starts instantly
- Download history and personal statistics (SQLite)
- Admin panel: stats, `/broadcast`, `/ban`, `/unban`
- Private mode (allow-list), daily limit, cooldown, max duration, job queue, cookies support
- Friendly error messages (private video, age-restricted, bot check, region block…)

## 📁 Structure
```
bot.py            entry point
config.py         settings from .env
handlers/         menu, downloader, admin, errors, access gate
services/         yt-dlp wrapper and helpers
database/         SQLite storage
ui/               message texts and keyboards
data/  work/      database / temporary downloads (auto-managed)
```

## 🚀 Install on Termux (Android) — step by step

1. Install **Termux from F-Droid** (the Play Store version is outdated): https://f-droid.org/packages/com.termux/
2. Open Termux and update:
   ```bash
   pkg update && pkg upgrade -y
   ```
3. Install the tools:
   ```bash
   pkg install python ffmpeg unzip nano tmux -y
   ```
4. Allow storage access (tap **Allow**), so Termux can see your Downloads folder:
   ```bash
   termux-setup-storage
   ```
5. Copy the zip into Termux's home folder and unzip it (adjust the file name if needed):
   ```bash
   cp ~/storage/downloads/ytv_downloader_pro.zip ~/
   cd ~
   unzip ytv_downloader_pro.zip
   cd ytv_downloader_pro
   ```
   ⚠️ Always run the bot from `~` (home), **not** from `/sdcard` or `~/storage/...`.
6. Install the Python packages:
   ```bash
   pip install -r requirements.txt
   ```
7. Create your bot: open Telegram → **@BotFather** → `/newbot` → follow the steps → copy the **token**.
8. Get your numeric Telegram ID from **@userinfobot** (this makes you the admin).
9. Create the settings file:
   ```bash
   cp .env.example .env
   nano .env
   ```
   Set `BOT_TOKEN=...` and `ADMIN_IDS=your_id`. Save in nano: **CTRL+O**, **Enter**, **CTRL+X**
   (Termux has a CTRL key in the extra keys row).
10. Start the bot:
    ```bash
    python bot.py
    ```
    You should see `Bot started as @yourbot`. Open your bot in Telegram and send `/start` 🎉

### Keep it running in the background
```bash
termux-wake-lock          # stop Android from sleeping the CPU
tmux new -s bot           # create a persistent session
python bot.py             # start the bot inside it
```
Detach with **CTRL+B** then **D**. Come back later with `tmux attach -t bot`.
Also set Termux to *Battery → Unrestricted* in Android settings.

### Update later
```bash
pip install -U yt-dlp     # do this whenever YouTube downloads start failing
```

## 💻 Install on Linux / VPS / Windows
```bash
sudo apt install python3 python3-pip ffmpeg -y        # Windows: install Python + ffmpeg and add to PATH
unzip ytv_downloader_pro.zip && cd ytv_downloader_pro
python3 -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env && nano .env
python bot.py
```
For 24/7 hosting on a VPS use `tmux`, or a systemd service.

## ⚙️ Settings (`.env`)
| Key | Meaning |
|---|---|
| `BOT_TOKEN` | Token from @BotFather (required) |
| `ADMIN_IDS` | Admin Telegram IDs, comma separated |
| `ALLOWED_USERS` | Private bot: only these IDs (empty = everyone) |
| `MAX_UPLOAD_MB` | Upload limit, 49 by default (Bot API limit) |
| `API_BASE_URL` | Self-hosted Bot API server (allows up to ~2 GB files) |
| `MAX_PLAYLIST_ITEMS` | Max playlist items per request (25) |
| `MAX_CONCURRENT_JOBS` | Parallel downloads (2) |
| `COOLDOWN_SECONDS` | Delay between link requests (5) |
| `DAILY_LIMIT` | Downloads per user per day, 0 = unlimited |
| `MAX_VIDEO_MINUTES` | Reject longer videos, 0 = no limit |
| `COOKIES_FILE` | Path to cookies.txt |
| `YTDLP_JS_RUNTIME` | Advanced, e.g. `node` (needs `pkg install nodejs`) |

## 🛠 Troubleshooting
- **`BOT_TOKEN is missing`** → `.env` not created, or you're not inside the project folder.
- **`ffmpeg is not installed`** → `pkg install ffmpeg`.
- **`ModuleNotFoundError`** → run `pip install -r requirements.txt` and start with `python bot.py` from inside `ytv_downloader_pro`.
- **`Conflict: terminated by other getUpdates request`** → the bot is running twice. Stop the other copy (`pkill -f bot.py`).
- **"YouTube asked for a bot check" / age-restricted** → export your YouTube cookies with a browser extension such as *Get cookies.txt LOCALLY*, save as `cookies.txt` in the project folder, then set `COOKIES_FILE=cookies.txt` in `.env` and restart. Use a spare account, never your main one.
- **Downloads suddenly fail** → `pip install -U yt-dlp`, restart the bot.
- **"File is above the upload limit"** → choose a lower quality, or run a self-hosted Bot API server and set `API_BASE_URL` + `MAX_UPLOAD_MB=1990`.

## ⚖️ Responsible use
Only download content you own or have permission to save, and respect YouTube's Terms of Service and copyright law in your country.
